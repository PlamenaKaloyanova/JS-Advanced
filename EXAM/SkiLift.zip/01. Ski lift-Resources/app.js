window.addEventListener('load', solve);

function solve() {

    let firstNameElement = document.getElementById('first-name');
    let lastNameElement = document.getElementById('last-name');
    let numberOfPeopleElement = document.getElementById('people-count');
    let fromDateElement = document.getElementById('from-date');
    let daysElement = document.getElementById('days-count');

    let nextStepButton = document.getElementById('next-btn');

    let ulInfoTicketsList = document.querySelector('.ticket-info-list');
    let ulConfirmTicketList = document.querySelector('.confirm-ticket');
    let divElementMain = document.getElementById('main');
    let bodyElement = document.getElementById('body');


    nextStepButton.addEventListener('click', (e) => {
        e.preventDefault();

        if (firstNameElement.value == "" || lastNameElement.value == "" || numberOfPeopleElement.value == "" || fromDateElement.value == "" || daysElement.value == "") {
            return;
        }

        let firsName = firstNameElement.value;
        let lastName = lastNameElement.value;
        let numberOfPeople = numberOfPeopleElement.value;
        let fromDate = fromDateElement.value;
        let days = daysElement.value;


        //създаваме ли елемент с клас ticket

        let liClassElementInfo = document.createElement('li');
        liClassElementInfo.classList.add('ticket');

        let articleElement = document.createElement('article');

        let h3ElementName = document.createElement('h3');
        h3ElementName.textContent = `Name: ${firsName} ${lastName}`;

        let pElementFromDate = document.createElement('p');
        pElementFromDate.textContent = `From date: ${fromDate}`;

        let pElementForDays = document.createElement('p');
        pElementForDays.textContent = `For ${days} days`;

        let pElementPeople = document.createElement('p');
        pElementPeople.textContent = `For ${numberOfPeople} people`;

        articleElement.appendChild(h3ElementName);
        articleElement.appendChild(pElementFromDate);
        articleElement.appendChild(pElementForDays);
        articleElement.appendChild(pElementPeople);
        liClassElementInfo.appendChild(articleElement);

        //СЪЗДАВАМ ДВА БУТОНА

        let editButton = document.createElement('button');
        editButton.classList.add('edit-btn');
        editButton.textContent = "Edit";

        let continueButton = document.createElement('button');
        continueButton.classList.add('continue-btn');
        continueButton.textContent = "Continue";

        liClassElementInfo.appendChild(editButton);
        liClassElementInfo.appendChild(continueButton);

        ulInfoTicketsList.appendChild(liClassElementInfo)


        nextStepButton.disabled = true;
        editButton.disabled = false;
        continueButton.disabled = false;

        firstNameElement.value = "";
        lastNameElement.value = "";
        numberOfPeopleElement.value = "";
        fromDateElement.value = "";
        daysElement.value = "";




        editButton.addEventListener('click', (e) => {
            firstNameElement.value = firsName;
            lastNameElement.value = lastName;
            numberOfPeopleElement.value = numberOfPeople;
            fromDateElement.value = fromDate;
            daysElement.value = days;

            nextStepButton.disabled = false;
            liClassElementInfo.remove()
        })

        continueButton.addEventListener('click', (e) => {

            liClassElementInfo.classList.remove('ticket');
            liClassElementInfo.classList.add('ticket-content')
            ulConfirmTicketList.appendChild(liClassElementInfo);

            editButton.remove();
            continueButton.remove();

            let confirmButton = document.createElement('button');
            confirmButton.classList.add('confirm-btn');
            confirmButton.textContent = "Confirm";

            let cancelButton = document.createElement('button');
            cancelButton.classList.add('cancel-btn');
            cancelButton.textContent = "Cancel"

            liClassElementInfo.appendChild(confirmButton);
            liClassElementInfo.appendChild(cancelButton)

            cancelButton.addEventListener('click', (e) => {
                liClassElementInfo.remove();
                nextStepButton.disabled = false;


            })
            confirmButton.addEventListener('click', (e) => {
                divElementMain.remove();

                let h1Element = document.createElement('h1');
                h1Element.setAttribute('id', 'thank-you');
                h1Element.textContent = "Thank you, have a nice day!";

                let buttonBack = document.createElement('button');
                buttonBack.setAttribute('id', 'back-btn');
                buttonBack.textContent = "Back";

                bodyElement.appendChild(h1Element);
                bodyElement.appendChild(buttonBack)

            })

            buttonBack.addEventListener('click', (e) => {

                buttonBack.setAttribute('onClick', 'reload')
            })

        })

    })


}




